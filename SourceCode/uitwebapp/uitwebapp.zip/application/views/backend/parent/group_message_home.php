<div class="mail-header">
    <!-- title -->
    <h3 class="mail-title">
        <?php echo get_phrase('group_messages'); ?>
    </h3>
</div>

<div style="width:100%; text-align:center;padding:100px;color:#aaa;">

    <i class="fa fa-comments" aria-hidden="true" style="font-size: 50px; color: #212121;"></i>
    <br>
    <div>
        <?php echo get_phrase('share_your_opinion'); ?>
    </div>
</div>
