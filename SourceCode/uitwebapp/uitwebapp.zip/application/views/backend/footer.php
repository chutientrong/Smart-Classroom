<!-- Footer -->
<footer class="main">
	&copy; 2022
	<a href="mailto:uit.contact@uit.edu.vn"
    	target="_blank">UIT VNU-HCM</a>
</footer>
