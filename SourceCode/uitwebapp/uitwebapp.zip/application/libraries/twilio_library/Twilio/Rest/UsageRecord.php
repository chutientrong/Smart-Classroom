<?php

class Services_Twilio_Rest_UsageRecord extends Services_Twilio_InstanceResource
{
}

